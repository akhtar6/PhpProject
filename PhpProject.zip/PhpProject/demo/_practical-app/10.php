<?php include "functions.php" ?>
<?php include "includes/header.php" ?>
<section class="content">

	<aside class="col-xs-4">

		<?php Navigation();?>
			
			
	</aside><!--SIDEBAR-->


<article class="main-content col-xs-8">
					     <!-- FUNCTION BELOW-->




<ul>
	
<script>

//Step 1 - Make an array of any name you want, assign it 5 values, and they can be anything you want..

//array here


//Step 2 - Make a variable called counter and set the value to zero

//variabel here

//Step 3 - Make a while loop and set the counter variable less than 5 


//loop here

// Step 4 - use document.write() inside the loop along with <li></li> html tags. Use the name of the array and use brackets to put the counter inside,  just like we did on the video.




</script>


</ul>

<h1 id="divContent"></h1>




</article><!--MAIN CONTENT-->

<?php include "includes/footer.php" ?>