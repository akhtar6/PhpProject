<?php include "functions.php" ?>
<?php include "includes/header.php" ?>



	<section class="content">

		<aside class="col-xs-4">

		<?php Navigation();?>
			
			
		</aside><!--SIDEBAR-->


		<article class="main-content col-xs-8">
			
<!-- Step 1

PUT AN onclick even handler on this button below and call and alert() 
function saying anything you want, like we did on the video. 

-->

<button id="theButton" class="btn btn-primary">SUBMIT</button>




<!--Step 2 Open this page and refresh -->
	

<!-- NEXT....We are going to handle events differently by using document.getElementById() with onclick().Don't Panic I will help you on this a little :) -->


<!--********************NEXT SECTION **************-->

<!--STEP 1 - Create a button with an id of clickMe that says Click Me-->




<!--BUTTON HERE-->



<script>


// Step 2 Make a function with the name ClickMe and inside the curly brakets call an alert() function to display any text you want.




//function here........




//document.write() here.......






// Step 3 Create a document.getElementById() and put the Id you made in Step 1 inside the parentheses.

// code here.....

// Step 4. Use a dot notation to append onclick = function(){} to the document.getELementById().




//Step 5 Put the name of the function Clickme inside the curly brackets of the Step 3 function you made, and remember to put a semicolon for this statement at end in the curly bracket.

	

//Step 6 -Open your page and refresh, and click the button that says CLICK ME







</script>



<script>

</script>

<h1 id="divContent"></h1>





















	

		</article><!--MAIN CONTENT-->
<?php include "includes/footer.php" ?>