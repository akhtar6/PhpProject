<?php include "functions.php" ?>
<?php include "includes/header.php" ?>

<section class="content">

    <aside class="col-xs-4">

        <?php Navigation();?>


    </aside>
    <!--SIDEBAR-->


    <article class="main-content col-xs-8">


        <?php  
/*         Step 1 - Create a database in PHPmyadmin */
            checkConnection();
?>
        <?php     
/*         Step 2 - Create a table like the one from the lecture */
        
?>



        <form action="7.php" method="post">
            <div class="form-group">
                <label for="name">Name</label>
                <input type="text" class="form-control" name="name">
            </div>
            <div class="form-group">
                <label for="roll">Roll</label>
                <input type="text" class="form-control" name="roll">
            </div>
            <div class="form-group">
                <label for="class">Class</label>
                <input type="text" class="form-control" name="class">
            </div>
            <div class="form-group">
                <label for="phone">Phone</label>
                <input type="text" class="form-control" name="phone">
            </div>
            <div class="form-group">
                <label for="adress">Adress</label>
                <input type="text" class="form-control" name="address">
            </div>
            <input type="submit" name="submit" class="btn btn-primary" value="SUBMIT">
        </form>




        <?php        
/*          Step 3 - Insert some Data */
            classInfo();
        ?>


        <?php              
/*          Step 4 - Connect to Database and read data */ ?>
        <pre>
            <?php
                showData();
            ?>
        </pre>





    </article>
    <!--MAIN CONTENT-->

    <?php include "includes/footer.php" ?>
