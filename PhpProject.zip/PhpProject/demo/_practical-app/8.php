<?php include "functions.php" ?>
<?php include "includes/header.php" ?>

	<section class="content">

		<aside class="col-xs-4">

		<?php Navigation();?>
			
			
		</aside><!--SIDEBAR-->


		<article class="main-content col-xs-8">

					     <!-- FUNCTION BELOW-->
			


<script>

// Step 1 - Make a empty function and name it whatever you want






//Code here..................


    function emptyFunction(){
        $message = "Alert You Bitch Can YOU IMAGINE THAT YOU ARE WASTING YOUR TIME IN A FUCKING GAME";
        
        alert($message);
    }
    
    emptyFunction();




// Step 2 - Inside the curly brakets delare a variable called message and assign it any string(text) you want, maybe like a message of some sort :)



//Step 3 Inside the function also place an alert() function and place the name of the variable you just made inside. 



//Step 4 - now call the function: If you don't the function will not start, remmember from the video?


//Step 5 - Open This page if not open and refresh 34937



</script>

<h1 id="divContent"></h1>





















	

		</article><!--MAIN CONTENT-->
<?php include "includes/footer.php" ?>