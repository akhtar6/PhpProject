<?php 


function Navigation(){


$activePage = basename($_SERVER['PHP_SELF']);
$rows = file('includes/navigation.txt');




echo "<ul class='nav'>";

foreach ($rows as $row) {
$nav = explode(":", $row);
$page = trim($nav[0]);
$link = trim($nav[1]);


if($link  == $activePage) {


echo "<li class='activeLink'><a href='{$link}'>" . $page . "</a></li>";


} else {

	echo  "<li><a href='" . $link . "'>" . $page . "</a></li>";

}




}

echo "</ul>";



}




function getTitle(){

$activePage = basename($_SERVER['PHP_SELF']);
$rows = file('includes/navigation.txt');

foreach ($rows as $row) {
$nav = explode(":", $row);
$page = trim($nav[0]);
$link = trim($nav[1]);

if($link  == $activePage) {

echo $page;

} else {



}



}

}



function checkConnection(){
        $connection =  mysqli_connect('localhost', 'root', '', 'class_info');
    
    if (!$connection){
        die("Database Connection Error" . mysqli_error($connection));
    }
}

function classInfo(){
    $connection =  mysqli_connect('localhost', 'root', '', 'class_info');
    if (isset($_POST["submit"])){
        $name = $_POST["name"];
        $roll = $_POST["roll"];
        $class = $_POST["class"];
        $phone = $_POST["phone"];
        $address = $_POST["address"];
        
        
        $query = "INSERT INTO students(name, roll, class, phone, address) VALUES ('$name', '$roll', '$class', '$phone', '$address')";
        
        
        $result = mysqli_query($connection , $query);
        
        if (!$result){
            die("QUERY FAILED");
        }else{
            echo "User Added Successfully";
        }
    }
}


function showData(){
    $connection = mysqli_connect('localhost', 'root', '', 'class_info');
    
    $query = "SELECT * FROM students ";
    
    
    $result = mysqli_query($connection, $query);
    
    if(!$result){
        die ("QUERY FAILED" . mysqli_error($result));
    }else{
        echo "Query Successful";
    }
    
    
    while($row = mysqli_fetch_assoc($result)){
        ?>
        
        <pre>
            <?php print_r($row); ?>
        </pre>
        
<?php
    }
}










?>



