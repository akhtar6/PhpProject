<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body>
<?php 

$number1 = 30;
$number2 = 30;
  
echo ((10 + 20 + $number1) * $number2) / 45 - 2;

echo "<br>";

echo pow(4, 24);

echo "<br>";

echo sqrt(200);

echo "<br>";

echo rand();

echo "<br>";

echo rand(1, 1000);



echo "<br>";

echo ceil(10.6);

    
?>



</body>
</html>