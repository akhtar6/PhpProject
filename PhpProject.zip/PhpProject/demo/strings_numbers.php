<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body>
   

<?php echo "<h1>PHP Hello Student</h1>"?>

<br>

<h1>HTML first line</h1>

<?php echo "PHP Sencond PHP LINE";?> 

<h2> HTML Second line</h2> 

<br>

<?php echo 456 + 456;?>
    
</body>
</html>