<?php 

class Car {
    
    
    
    


}

if(class_exists("Car")) {

echo "YEayyyyyyyyy Nice";

} else {

echo "no";

}





?>