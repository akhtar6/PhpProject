<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body>
<?php 
    
$list = array(1000,20,2,46,5,6,100,8,12,14,16);

echo max($list);

echo "<br>";

echo min($list);

echo "<br>";

sort($list); print_r($list)

    
?>

</body>
</html>