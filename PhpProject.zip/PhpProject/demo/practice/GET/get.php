<?php include "../includes/header.php" ?>

<div class="index">
    <div class="header">
        <h1>This is Header</h1>
    </div>
    <div class="container">
        <div class="col-sm-6">
            <h1>SUPER GLOBAL GET</h1>
            <hr style="background-color: #fff; height: 1px; width: 290px;">
            <hr style="background-color: #fff; height: 1px; width: 290px; margin-top: -13px;">

            <?php print_r($_GET); ?>

            <a href="get.php?id=10&users=20">CLICK HERE</a>
        </div>
    </div>
    <div class="footer">
        <h1>This is Footer</h1>
    </div>
</div>

<?php include "../includes/footer.php" ?>
