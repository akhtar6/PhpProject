<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Login Form Practice</title>
    <link rel="stylesheet" href="../bootstrap.min.css" type="text/css">
    <link rel="stylesheet" href="../style.css">
</head>

<body>
    <div class="index">
        <div class="header">
            <h1>This is Header</h1>
        </div>
        <div class="container">
            <div class="col-sm-6">
                <form action="login2.php" method="post">
                    <div class="form-group">
                        <label for="username">Username</label>
                        <input type="text" class="form-control" name="username">
                    </div>
                    <div class="form-group">
                        <label for="email">Email</label>
                        <input type="text" class="form-control" name="email">
                    </div>
                    <div class="form-group">
                        <label for="password">Password</label>
                        <input type="password" class="form-control" name="password">
                    </div>
                    <input type="submit" name="submit" class="btn btn-primary" value="Submit">
                </form>
                                    
<?php
    if(isset($_POST["submit"])){
        $username = $_POST["username"];
        $password = $_POST["password"];
        $email = $_POST["email"];
        
        
        $connection = mysqli_connect('localhost', 'root', '', 'loginapp');
        
        if($connection){
            echo "We are Successfully Connected";
        }else{
            die("Database Connection Error");
        }
    }
?>
            </div>
        </div>
        <div class="footer">
            <h1>This is Footer</h1>
        </div>
    </div>
</body>

</html>
