<?php include "databases.php";?>
<?php include "functions.php";?>