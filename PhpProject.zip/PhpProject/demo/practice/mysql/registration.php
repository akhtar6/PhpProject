<?php include "databases.php";?>
<?php include "functions.php";?>
<?php createData(); ?>
<?php include "includes/header.php" ?>
<div class="index">
    <div class="header">
        <h1>This is Header</h1>
    </div>
    <div class="container">
        <div class="col-sm-6">
            <h1 class="text-center">Registration</h1>
            <hr style="background-color: #fff; height: 1px; width: 215px;">
            <hr style="background-color: #fff; height: 1px; width: 215px; margin-top: -13px;">
            <form action="registration.php" method="post">
                <div class="form-group">
                    <label for="username">Username</label>
                    <label>
                        <input type="text" class="form-control" name="username">
                    </label>
                </div>
                <div class="form-group">
                    <label for="email">Email</label>
                    <label>
                        <input type="email" class="form-control" name="email">
                    </label>
                </div>
                <div class="form-group">
                    <label for="password">Password</label>
                    <label>
                        <input type="password" class="form-control" name="password">
                    </label>
                </div>
                <input type="submit" name="submit" class="btn btn-primary" value="Register">
            </form>

        </div>
    </div>
    <div class="footer">
        <h1>This is Footer</h1>
    </div>
</div>
<?php include "includes/footer.php" ?>
