<?php include "databases.php"?>
<?php
    
//To Creat a new data for user with all information
function createData(){
    if(isset($_POST["submit"])){
        $username = $_POST["username"];
        $email = $_POST["email"];
        $password = $_POST["password"];
        

        $connection = mysqli_connect('localhost', 'root', '', 'loginapp');

        if(!$connection){
            die("Database Connection Error");
        }else{
            echo "SUCCESSFULLY REGISTERED";
        }
        
        
        
        $username = mysqli_real_escape_string($connection, $username);
        $password = mysqli_real_escape_string($connection, $password);
        

        
        
        $hashFormat = "$2y$10$";
        
        $salt = "iusesomecrazystrings22";
        
        $hashF_and_salt = $hashFormat . $salt ;
        
        $password = crypt($password, $hashF_and_salt);
        
        

        $query = "INSERT INTO users(username, email, password) VALUES ('$username', '$email', '$password')";


        $result = mysqli_query($connection, $query);

        if(!$result){
            die('QUERY FAILED' . mysqli_error($result));
        }
}
}
    
    
    
//To Read The user submited data
function readRows(){
    global $connection;
    $query = "SELECT * FROM users ";
    $result = mysqli_query($connection, $query);

    if(!$result){
    die('QUERY FAILED');
    }
        while($row = mysqli_fetch_assoc($result)){
            print_r($row);
        }
}

    
    
//To See the user list
function showAllData(){
    global $connection;
    $query = 'SELECT * FROM users ';    
    $result = mysqli_query($connection, $query);
    if(!$result){
        die('QUERY FAILED');
    }
    while($row = mysqli_fetch_assoc($result)){
        $id = $row['id'];
        echo "<option value='$id'>$id</option>";
    }
}



//To update the user information
function updateTable(){
    global $connection;
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $id = $_POST['id'];


    $query = "UPDATE users SET ";
    $query .= "username = '$username', ";
    $query .= "email = '$email', ";
    $query .= "password = '$password' ";
    $query .= "WHERE id = $id ";


    $result = mysqli_query($connection, $query);
    if(!$result){
        die("QUERY FAILED" . mysqli_error($connection));
    }else {
        echo "Informtion Successfully Updated";
    }
}



//To Delete user information from the list
function deleteRows(){
    global $connection;
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $id = $_POST['id'];


    $query = "DELETE FROM users ";
    $query .= "WHERE id = $id ";


    $result = mysqli_query($connection, $query);
    if(!$result){
        die("QUERY FAILED" . mysqli_error($connection));
    }else{
        echo "User Data DELETED Successfully";
    }
}