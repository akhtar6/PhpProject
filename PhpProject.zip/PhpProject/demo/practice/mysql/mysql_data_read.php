<?php include "functions.php";?>
<?php include "includes/header.php" ?>
<div class="index">
    <div class="header">
        <h1>This is Header</h1>
    </div>
    <div class="container2 container-height">
        <h1 class="text-center">Registration</h1>
        <hr style="background-color: #fff; height: 1px; width: 215px;">
        <hr style="background-color: #fff; height: 1px; width: 215px; margin-top: -13px;">
        <div class="col-sm-6">
            <form action="read_data_process.php">
                <input type="submit" name="submit" class="btn btn-primary button-style" value="Read Data">
            </form>
        </div>
    </div>
    <div class="footer">
        <h1>This is Footer</h1>
    </div>
</div>

<?php include "includes/footer.php" ?>
