<?php
    if(isset($_POST["submit"])){
        $username = $_POST["username"];
        $email = $_POST["email"];
        $password = $_POST["password"];
        }

    $connection = mysqli_connect('localhost', 'root', '', 'loginapp');
        
        if(!$connection){
            die("Database Connection Error");
        }
                
    
    $query = "SELECT * FROM users ";
                
    
    $result = mysqli_query($connection, $query);
                
    if(!$result){
        die('QUERY FAILED');
    }



    while($row = mysqli_fetch_assoc($result)){
?>
        <pre>
            <?php print_r($row); ?>
        </pre>

<?php
    }
?>
