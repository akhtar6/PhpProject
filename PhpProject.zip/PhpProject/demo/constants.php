<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body>
   
<?php 

$number = 10;

$number = 345;

define('NUMBER', 1000);

//NUMBER = 34532;

echo 'constant ' . NUMBER;
echo "<br>";
echo 'variable ' .  $number;
    
    
?>   
   
    
</body>
</html>